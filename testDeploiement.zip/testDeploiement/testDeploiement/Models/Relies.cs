﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Relies
    {
        public string CodeLivre { get; set; }
        public string Titre { get; set; }
        public decimal? Prix { get; set; }
        public string NomEditeur { get; set; }
    }
}
