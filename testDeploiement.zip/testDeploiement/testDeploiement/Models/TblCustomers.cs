﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class TblCustomers
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Country { get; set; }
        public DateTime? CreationDate { get; set; }
    }
}
