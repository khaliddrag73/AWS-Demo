﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Branches
    {
        public Branches()
        {
            Inventaire = new HashSet<Inventaire>();
        }

        public int Nobranche { get; set; }
        public string NomBranche { get; set; }
        public string AdrBranche { get; set; }
        public byte? NbEmployes { get; set; }

        public virtual ICollection<Inventaire> Inventaire { get; set; }
    }
}
