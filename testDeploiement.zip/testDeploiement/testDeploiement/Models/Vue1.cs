﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Vue1
    {
        public string Colonne { get; set; }
    }
}
