﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Editeurs
    {
        public Editeurs()
        {
            Livres = new HashSet<Livres>();
        }

        public string CodeEditeur { get; set; }
        public string NomEditeur { get; set; }
        public string Ville { get; set; }
        public string Etat { get; set; }

        public virtual ICollection<Livres> Livres { get; set; }
    }
}
