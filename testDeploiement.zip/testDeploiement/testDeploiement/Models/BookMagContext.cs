﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace testDeploiement.Models
{
    public partial class BookMagContext : DbContext
    {
        public BookMagContext()
        {
        }

        public BookMagContext(DbContextOptions<BookMagContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Auteurs> Auteurs { get; set; }
        public virtual DbSet<Branches> Branches { get; set; }
        public virtual DbSet<Customer> Customer { get; set; }
        public virtual DbSet<EcritPar> EcritPar { get; set; }
        public virtual DbSet<Editeurs> Editeurs { get; set; }
        public virtual DbSet<Host> Host { get; set; }
        public virtual DbSet<Inventaire> Inventaire { get; set; }
        public virtual DbSet<Livres> Livres { get; set; }
        public virtual DbSet<Rapport1> Rapport1 { get; set; }
        public virtual DbSet<Relies> Relies { get; set; }
        public virtual DbSet<TblCustomers> TblCustomers { get; set; }
        public virtual DbSet<TblOrders> TblOrders { get; set; }
        public virtual DbSet<Vue1> Vue1 { get; set; }
        public virtual DbSet<Vue2> Vue2 { get; set; }
        public virtual DbSet<Vue3> Vue3 { get; set; }
        public virtual DbSet<Vue4> Vue4 { get; set; }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
       // {
           //if (!optionsBuilder.IsConfigured)
            //{
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                //optionsBuilder.UseSqlServer("Data Source=DESKTOP-R8AN759;Initial Catalog=BookMag;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;MultipleActiveResultSets=true");
            //}
        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Auteurs>(entity =>
            {
                entity.HasKey(e => e.Noauteur)
                    .HasName("PK_AUTEUR");

                entity.ToTable("AUTEURS");

                entity.Property(e => e.Noauteur)
                    .HasColumnName("NOAUTEUR")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Nom)
                    .HasColumnName("NOM")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .IsFixedLength()
                    .HasDefaultValueSql("('Auteur')");

                entity.Property(e => e.Prenom)
                    .HasColumnName("PRENOM")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Branches>(entity =>
            {
                entity.HasKey(e => e.Nobranche)
                    .HasName("PK_BRANCHE");

                entity.ToTable("BRANCHES");

                entity.HasIndex(e => e.NomBranche)
                    .HasName("PK_NOM")
                    .IsUnique();

                entity.Property(e => e.Nobranche).HasColumnName("NOBRANCHE");

                entity.Property(e => e.AdrBranche)
                    .HasColumnName("ADR_BRANCHE")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.NbEmployes).HasColumnName("NB_EMPLOYES");

                entity.Property(e => e.NomBranche)
                    .HasColumnName("NOM_BRANCHE")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Email)
                    .HasColumnName("email")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasColumnName("first_name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .HasColumnName("gender")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasColumnName("last_name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .HasColumnName("phone")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<EcritPar>(entity =>
            {
                entity.HasKey(e => new { e.CodeLivre, e.Noauteur })
                    .HasName("PK_ECRITPAR");

                entity.ToTable("ECRIT_PAR");

                entity.Property(e => e.CodeLivre)
                    .HasColumnName("CODE_LIVRE")
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Noauteur)
                    .HasColumnName("NOAUTEUR")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Sequence)
                    .HasColumnName("SEQUENCE")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength()
                    .HasDefaultValueSql("('1')");

                entity.HasOne(d => d.CodeLivreNavigation)
                    .WithMany(p => p.EcritPar)
                    .HasForeignKey(d => d.CodeLivre)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LIVRE");

                entity.HasOne(d => d.NoauteurNavigation)
                    .WithMany(p => p.EcritPar)
                    .HasForeignKey(d => d.Noauteur)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AUTEUR");
            });

            modelBuilder.Entity<Editeurs>(entity =>
            {
                entity.HasKey(e => e.CodeEditeur)
                    .HasName("PK_EDITEUR");

                entity.ToTable("EDITEURS");

                entity.HasIndex(e => e.NomEditeur)
                    .HasName("PK_NOM_EDITEUR")
                    .IsUnique();

                entity.Property(e => e.CodeEditeur)
                    .HasColumnName("CODE_EDITEUR")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Etat)
                    .HasColumnName("ETAT")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.NomEditeur)
                    .HasColumnName("NOM_EDITEUR")
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Ville)
                    .HasColumnName("VILLE")
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Host>(entity =>
            {
                entity.ToTable("host");

                entity.Property(e => e.HostId).HasColumnName("host_id");

                entity.Property(e => e.HostIp)
                    .HasColumnName("host_ip")
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.HostName)
                    .HasColumnName("host_name")
                    .HasMaxLength(45)
                    .IsUnicode(false);

                entity.Property(e => e.LastDateConnection)
                    .HasColumnName("last_date_connection")
                    .HasColumnType("datetime");

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasMaxLength(15)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Inventaire>(entity =>
            {
                entity.HasKey(e => new { e.CodeLivre, e.Nobranche })
                    .HasName("PK_INVENTAIR");

                entity.ToTable("INVENTAIRE");

                entity.Property(e => e.CodeLivre)
                    .HasColumnName("CODE_LIVRE")
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Nobranche).HasColumnName("NOBRANCHE");

                entity.Property(e => e.Qte).HasColumnName("QTE");

                entity.HasOne(d => d.CodeLivreNavigation)
                    .WithMany(p => p.Inventaire)
                    .HasForeignKey(d => d.CodeLivre)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LIVRE_1");

                entity.HasOne(d => d.NobrancheNavigation)
                    .WithMany(p => p.Inventaire)
                    .HasForeignKey(d => d.Nobranche)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BRANCHE");
            });

            modelBuilder.Entity<Livres>(entity =>
            {
                entity.HasKey(e => e.CodeLivre)
                    .HasName("PK_LIVRE");

                entity.ToTable("LIVRES");

                entity.HasIndex(e => e.Titre)
                    .HasName("CK_TITRES")
                    .IsUnique();

                entity.Property(e => e.CodeLivre)
                    .HasColumnName("CODE_LIVRE")
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CodeEditeur)
                    .IsRequired()
                    .HasColumnName("CODE_EDITEUR")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Genre)
                    .HasColumnName("GENRE")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Poche)
                    .HasColumnName("POCHE")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength()
                    .HasDefaultValueSql("('O')");

                entity.Property(e => e.Prix)
                    .HasColumnName("PRIX")
                    .HasColumnType("smallmoney");

                entity.Property(e => e.Titre)
                    .HasColumnName("TITRE")
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.HasOne(d => d.CodeEditeurNavigation)
                    .WithMany(p => p.Livres)
                    .HasForeignKey(d => d.CodeEditeur)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EDITEUR");
            });

            modelBuilder.Entity<Rapport1>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Rapport1");

                entity.Property(e => e.NomEditeur)
                    .HasColumnName("Nom_Editeur")
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.VilleEtat)
                    .HasColumnName("Ville_Etat")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Relies>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("relies");

                entity.Property(e => e.CodeLivre)
                    .IsRequired()
                    .HasColumnName("CODE_LIVRE")
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.NomEditeur)
                    .HasColumnName("NOM_EDITEUR")
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Prix)
                    .HasColumnName("PRIX")
                    .HasColumnType("smallmoney");

                entity.Property(e => e.Titre)
                    .HasColumnName("TITRE")
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<TblCustomers>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tbl_customers");

                entity.Property(e => e.Country)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreationDate).HasColumnType("datetime");

                entity.Property(e => e.CustomerId)
                    .HasColumnName("CustomerID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.CustomerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblOrders>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tbl_orders");

                entity.Property(e => e.Amount).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.OrderDate).HasColumnType("datetime");

                entity.Property(e => e.OrderId)
                    .HasColumnName("OrderID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<Vue1>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vue1");

                entity.Property(e => e.Colonne)
                    .HasColumnName("colonne")
                    .HasMaxLength(58)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Vue2>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Vue2");

                entity.Property(e => e.Branche)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.NomEditeur)
                    .HasColumnName("Nom_Editeur")
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Prix).HasColumnType("smallmoney");

                entity.Property(e => e.Titre)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.VilleEtat)
                    .HasColumnName("Ville_Etat")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Vue3>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Vue3");

                entity.Property(e => e.NomPrenomAuteur)
                    .HasColumnName("Nom_Prenom_Auteur")
                    .HasMaxLength(42)
                    .IsUnicode(false);

                entity.Property(e => e.NombreLivresPoche).HasColumnName("Nombre_Livres_Poche");

                entity.Property(e => e.NombreMoyenLivres)
                    .HasColumnName("Nombre_moyen_Livres")
                    .HasColumnType("money");
            });

            modelBuilder.Entity<Vue4>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Vue4");

                entity.Property(e => e.PremierDeuxiemeLivre)
                    .HasColumnName("Premier_Deuxieme_Livre")
                    .HasMaxLength(91)
                    .IsUnicode(false);

                entity.Property(e => e.Titre)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
