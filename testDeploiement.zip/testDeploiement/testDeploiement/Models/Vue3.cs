﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Vue3
    {
        public string NomPrenomAuteur { get; set; }
        public int? NombreLivresPoche { get; set; }
        public decimal? NombreMoyenLivres { get; set; }
    }
}
