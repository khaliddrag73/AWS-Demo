﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Host
    {
        public int HostId { get; set; }
        public string HostName { get; set; }
        public string HostIp { get; set; }
        public string Status { get; set; }
        public DateTime? LastDateConnection { get; set; }
    }
}
