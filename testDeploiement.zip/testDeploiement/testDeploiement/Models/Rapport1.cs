﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Rapport1
    {
        public string NomEditeur { get; set; }
        public string VilleEtat { get; set; }
    }
}
