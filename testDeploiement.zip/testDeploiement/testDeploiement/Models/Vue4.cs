﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Vue4
    {
        public string Titre { get; set; }
        public string PremierDeuxiemeLivre { get; set; }
    }
}
