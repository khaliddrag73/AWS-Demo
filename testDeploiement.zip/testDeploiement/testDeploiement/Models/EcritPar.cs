﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class EcritPar
    {
        public string CodeLivre { get; set; }
        public string Noauteur { get; set; }
        public string Sequence { get; set; }

        public virtual Livres CodeLivreNavigation { get; set; }
        public virtual Auteurs NoauteurNavigation { get; set; }
    }
}
