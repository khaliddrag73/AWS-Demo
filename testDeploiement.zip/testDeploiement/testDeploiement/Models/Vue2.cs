﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Vue2
    {
        public string NomEditeur { get; set; }
        public string VilleEtat { get; set; }
        public string Titre { get; set; }
        public decimal? Prix { get; set; }
        public byte? Stock { get; set; }
        public string Branche { get; set; }
    }
}
