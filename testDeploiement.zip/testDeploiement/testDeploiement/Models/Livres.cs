﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Livres
    {
        public Livres()
        {
            EcritPar = new HashSet<EcritPar>();
            Inventaire = new HashSet<Inventaire>();
        }

        public string CodeLivre { get; set; }
        public string Titre { get; set; }
        public string CodeEditeur { get; set; }
        public string Genre { get; set; }
        public decimal? Prix { get; set; }
        public string Poche { get; set; }

        public virtual Editeurs CodeEditeurNavigation { get; set; }
        public virtual ICollection<EcritPar> EcritPar { get; set; }
        public virtual ICollection<Inventaire> Inventaire { get; set; }
    }
}
