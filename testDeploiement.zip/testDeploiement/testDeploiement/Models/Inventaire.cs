﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Inventaire
    {
        public string CodeLivre { get; set; }
        public int Nobranche { get; set; }
        public byte? Qte { get; set; }

        public virtual Livres CodeLivreNavigation { get; set; }
        public virtual Branches NobrancheNavigation { get; set; }
    }
}
