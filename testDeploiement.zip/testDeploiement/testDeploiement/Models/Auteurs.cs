﻿using System;
using System.Collections.Generic;

namespace testDeploiement.Models
{
    public partial class Auteurs
    {
        public Auteurs()
        {
            EcritPar = new HashSet<EcritPar>();
        }

        public string Noauteur { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }

        public virtual ICollection<EcritPar> EcritPar { get; set; }
    }
}
