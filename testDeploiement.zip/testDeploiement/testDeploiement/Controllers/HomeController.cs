﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using testDeploiement.Models;

namespace testDeploiement.Controllers
{
    public class HomeController : Controller
    {
        private readonly BookMagContext context;
        public HomeController(BookMagContext _context)
        {
            context = _context;
        }
        public IActionResult Index()
        {
            return View(context.Customer);
        }
    }
}
