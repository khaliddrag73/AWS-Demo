﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Projet.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Projet.Controllers
{
    public class HomeController : Controller
    {
        private readonly GestionQuizsContext context;
        //Garder en mémoire les questions et les réponses de l'étudiant
        private static List<Question> listQuestions { get; set; }
        private static List<int> listAnswers { get; set; }

        public object Session { get; private set; }

        public HomeController(GestionQuizsContext _context)
        {
            context = _context;
        }
        [HttpGet]
        public IActionResult Index()
        {
            listQuestions = new List<Question>();
            listAnswers = new List<int>();
            //Première action, afficher la page des questions
            return View();
        }
        [HttpPost]
        public IActionResult Index(User user)
        {
            Boolean valid = false;
            //L'utilsateur doit saisir un login et un mot de passe pour se connecter
            if (user.Email == null)
            {
                ViewBag.email = "Il faut saisir une adresse courriel!";
                return View("Index");
            }
            else if (user.Password == null)
            {
                ViewBag.password = "Il faut saisir un mot de passe!";
                return View("Index");
            }
            foreach (var item in context.Users)
            {
                if ((item.Email.ToLower() == user.Email.ToLower()) && (item.Password == user.Password))
                {
                    valid = true;//Authentification réussie
                    //Mémoriser l'email, le nom-prénom et le statut
                    HttpContext.Session.SetString("email", item.Email);
                    HttpContext.Session.SetString("nom", item.Prenom + " " + item.Nom);
                    HttpContext.Session.SetString("statut", item.Statut);
                    break;
                }
            }
            if (valid)
            {
                //Afficher tous les quizs de l'utilisateur
                var quizs = context.Quizzes.Where(qt => qt.Email == HttpContext.Session.GetString("email"));
                if (quizs.Count() == 0)
                {
                    if (HttpContext.Session.GetString("statut") == "Etudiant")
                        return View("New");
                    else
                        return View("Users", context.Users.Where(user => user.Statut == "Etudiant"));
                }
                return View("Quizs", quizs);
            }
            else
            {
                ViewBag.error = "Login ou mot de passe incorrect!";
                return View("index");
            }
        }
        [HttpGet]
        public IActionResult Enseignant()
        {
            //Ajouter une question
            return View();
        }
        [HttpPost]
        public IActionResult Enseignant(string question, int category, int isRight)
        {
            //Récupérer les options
            var opt1 = Request.Form["option1"].ToString();
            var opt2 = Request.Form["option2"].ToString();
            var opt3 = Request.Form["option3"].ToString();
            var opt4 = Request.Form["option4"].ToString();
            var opts = new List<string>() { opt1, opt2, opt3, opt4 };
            //Tous les champs sont obligatoires
            if (question == null || category == 0 || isRight == 0 || opt1 == null || opt2 == null || opt3 == null || opt4 == null)
            {
                ViewBag.error = "All fields are required";
                return View();
            }
            //Sauvegarder la question avec ses options
            Question qt = new Question() { Texte = question, CategoryId = category };
            context.Questions.Add(qt);
            context.SaveChanges();
            int last = context.Questions.OrderByDescending(e => e.QuestionId).First().QuestionId;
            for(var i = 0; i < 4; i++)
            {
                Option opt = new Option() { Texte = opts[i], IsRight = (isRight == i + 1) ? true : false, QuestionId = last };
                context.Options.Add(opt);
                context.SaveChanges();
            }
            return View("Users", context.Users.Where(user => user.Statut == "Etudiant"));
        }
        [HttpGet]
        public IActionResult New()
        {
            //La page de la création d'un nouveau quiz
            //Chercher le nombre de questions easy, medium, et hard
            ViewBag.easy = context.Questions.Where(item => item.CategoryId == 1).Count();
            ViewBag.medium = context.Questions.Where(item => item.CategoryId == 2).Count();
            ViewBag.hard = context.Questions.Where(item => item.CategoryId == 3).Count();
            return View();
        }
        [HttpPost]
        public IActionResult New(int easy, int medium, int hard)
        {
            if (easy != 0 && medium != 0 && hard != 0)
            {
                //Générer aléatoirement les questions pour chaque catégorie
                random(easy, listQuestions, 1);
                random(medium, listQuestions, 2);
                random(hard, listQuestions, 3);
                int lastIndex = 0;
                Quiz quiz;
                //Si l'utilisateur est étudiant, le quiz est crée pour lui tout seul, avec un nom composé
                //du mot "Quiz" + l'identifiant du nouveau quiz
                if (HttpContext.Session.GetString("statut") == "Etudiant")
                {
                    if (context.Quizzes.Count() > 0)
                        lastIndex = context.Quizzes.OrderByDescending(e => e.QuizId).First().QuizId;
                    string nom = "Quiz" + (lastIndex + 1);
                    quiz = new Quiz() { Nom = nom, Email = HttpContext.Session.GetString("email") };
                    context.Quizzes.Add(quiz);
                    context.SaveChanges();
                    foreach (var qt in listQuestions)
                    {
                        context.QuestionQuizzes.Add(new QuestionQuiz() { QuizId = lastIndex + 1, QuestionId = qt.QuestionId });
                        context.SaveChanges();
                    }
                }
                //Si c'est un enseignant, le quiz est crée pour l'enseignant et pour tous les étudiant
                //Avec un nom composé du mot "Examen" + l'identifiant du dernier examen + 1
                else
                {
                    int index = 0;
                    var students = context.Users.Where(std => std.Statut == "Etudiant").ToList();
                    //Chercher le dernier examen passé, et extraire les derniers chiffres et les incrémenter par 1
                    if (context.Quizzes.Where(qz => qz.Nom.Contains("Examen")).ToList().Count() > 0)
                        index = Int32.Parse(context.Quizzes.Where(qz => qz.Nom.Contains("Examen")).ToList().Last().Nom.Substring(6));
                    if (context.Quizzes.Count() > 0)
                        lastIndex = context.Quizzes.OrderByDescending(e => e.QuizId).First().QuizId;
                    //Créer le quiz pour l'enseignant
                    quiz = new Quiz() { Nom = "Examen" + (index + 1), Email = HttpContext.Session.GetString("email")};
                    context.Quizzes.Add(quiz);
                    context.SaveChanges();
                    foreach (var qt in listQuestions)
                    {
                        context.QuestionQuizzes.Add(new QuestionQuiz() { QuizId = lastIndex + 1, QuestionId = qt.QuestionId });
                        context.SaveChanges();
                    }
                    //Créer le quiz pour tous les étudiants
                    foreach (var std in students)
                    {
                        lastIndex = context.Quizzes.OrderByDescending(e => e.QuizId).First().QuizId;
                        quiz = new Quiz() { Nom = "Examen" + (index + 1), Email = std.Email };
                        context.Quizzes.Add(quiz);
                        context.SaveChanges();
                        foreach (var qt in listQuestions)
                        {
                            context.QuestionQuizzes.Add(new QuestionQuiz() { QuizId = lastIndex + 1, QuestionId = qt.QuestionId });
                            context.SaveChanges();
                        }
                    }
                }
                listQuestions.Clear();
                return View("Quizs", context.Quizzes.Where(qz => qz.Email == HttpContext.Session.GetString("email")));
            }
            else
            {
                ViewBag.error = "All field required!";
                return View("New");
            }
        }
        public IActionResult Next(int answer, int indice, int noQuiz)
        {
            //Passer à la question suivante
            if (answer != 0)
            {
                listAnswers.Add(answer);
                if (indice == listQuestions.Count())
                {
                    int lastIndex = context.Quizzes.OrderByDescending(e => e.QuizId).First().QuizId;
                    //Insérer la réponse et le quiz dans Answers
                    foreach (var ans in listAnswers)
                    {
                        context.Answers.Add(new Answer() { QuizId = noQuiz, OptionId = ans });
                        context.SaveChanges();
                    }

                    listQuestions.Clear();
                    listAnswers.Clear();
                    var quizs = context.Quizzes.Where(qt => qt.Email == HttpContext.Session.GetString("email"));
                    return View("Quizs", quizs);
                }
            }
            else
            {
                indice -= 1;
                ViewBag.error = "Choose an answer!";
            }
            ViewBag.nom = HttpContext.Session.GetString("email");
            var options = context.Questions.Find(listQuestions[indice].QuestionId).Options;

            ViewBag.question = listQuestions[indice].Texte;
            ViewBag.indice = indice;
            ViewBag.noQuiz = noQuiz;
            ViewBag.length = listQuestions.Count();
            return View(options);
        }
        [HttpGet]
        public IActionResult Quizs()
        {
            //Afficher tous les quizs
            var qtQz = context.Quizzes.Where(qt => qt.Email == HttpContext.Session.GetString("email"));
            return View(qtQz);
        }

        [HttpPost]
        public IActionResult Quizs(int id)
        {
            //Afficher le quiz sélectionné
            if (context.Quizzes.Find(id).Answers.Count() == 0)
            {
                var qqs = context.Quizzes.Find(id).QuestionQuizzes;
                foreach (var qq in qqs)
                {
                    listQuestions.Add(qq.Question);
                }
                var options = context.Questions.Find(listQuestions[0].QuestionId).Options;
                ViewBag.question = listQuestions[0].Texte;
                ViewBag.indice = 0;
                ViewBag.length = listQuestions.Count();
                ViewBag.noQuiz = id;
                return View("Next", options);
            }
            else
            {
                ViewBag.error = "Quiz already done!";
                var quizs = context.Quizzes.Where(qt => qt.Email == HttpContext.Session.GetString("email"));
                return View("Quizs", quizs);
            }
        }
        public IActionResult Score(int id)
        {
            //Afficher résultat du quiz
            if (id == 0)
            {
                return View(context.Quizzes.Where(qt => qt.Email == HttpContext.Session.GetString("email")));
            }
            List<Answer> answers = context.Quizzes.Find(id).Answers.ToList();
            //Si le quiz n'a pas de réponse, signifie qu'il n'est pas encore passé
            if (answers.Count() > 0)
            {
                ViewBag.nom = HttpContext.Session.GetString("nom");
                List<Question> questions = new List<Question>();
                List<Option> options = new List<Option>();
                List<QuestionQuiz> qtQzs = context.Quizzes.Find(id).QuestionQuizzes.ToList();
                foreach (var qtQz in qtQzs)
                {
                    questions.Add(qtQz.Question);
                    foreach (var opt in qtQz.Question.Options)
                        options.Add(opt);
                }
                ViewBag.questions = questions;
                ViewBag.answers = answers;
                ViewBag.options = options;
                return View("Results");
            }
            else
            {
                ViewBag.error = "Quiz not yet done!";
                return View(context.Quizzes.Where(qt => qt.Email == HttpContext.Session.GetString("email")));
            }
        }
        public IActionResult Users()
        {
            //Afficher tous les utilisateurs
            return View(context.Users.Where(user => user.Statut == "Etudiant"));
        }
        public IActionResult Student(string Email)
        {
            //Afficher les quizs de l'étudiant
            User user = context.Users.Find(Email);
            ViewBag.name = user.Prenom + " " + user.Nom;
            return View(context.Quizzes.Where(qz => qz.Email == Email).ToList());
        }
        [HttpGet]
        public IActionResult AddStudent()
        {
            //Afficher le formulaire de l'ajout de l'étudiant
            return View();
        }
        [HttpPost]
        public IActionResult AddStudent(User user)
        {
            //Insérer l'étudiant si les données sont valides
            if (ModelState.IsValid)
            {
                context.Users.Add(user as User);
                context.SaveChanges();
                return View("Users", context.Users.Where(user => user.Statut == "Etudiant").ToList());
            }
            return View();
        }
        [HttpGet]
        public IActionResult DeleteStudent(string email)
        {
            //Confirmer la supression de l'étudiant
            return View(context.Users.Find(email));
        }
        [HttpPost]
        public IActionResult DeleteStudent(User user)
        {
            //Supprimer l'étudiant
            context.Users.Remove(user as User);
            context.SaveChanges();
            return View("Users", context.Users.Where(user => user.Statut == "Etudiant").ToList());
        }
        private void random(int nb, List<Question> list, int idCategory)
        {
            //Générer aléatoirement les questions pour une catégorie donnée
            int indice;
            Random index = new Random();
            var questionsByCategory = context.Categories.Find(idCategory).Questions.ToList();
            for (var i = 0; i < nb; i++)
            {
                indice = index.Next(questionsByCategory.Count());
                list.Add(questionsByCategory[indice]);
                questionsByCategory.RemoveAt(indice);
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
