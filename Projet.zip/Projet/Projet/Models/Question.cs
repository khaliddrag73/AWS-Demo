﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace Projet.Models
{
    public partial class Question
    {
        public Question()
        {
            Options = new HashSet<Option>();
            QuestionQuizzes = new HashSet<QuestionQuiz>();
        }
        [Key]
        public int QuestionId { get; set; }
        public string Texte { get; set; }
        public int? CategoryId { get; set; }

        public virtual Category Category { get; set; }
        public virtual ICollection<Option> Options { get; set; }
        public virtual ICollection<QuestionQuiz> QuestionQuizzes { get; set; }
    }
}
