-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: gestionquizs
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Easy'),(2,'Medium'),(3,'Hard');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` VALUES (1,'Staline',1,1),(2,'Trotski',0,1),(3,'Lénine',0,1),(4,'Molotov',0,1),(5,'Feindez!',0,2),(6,'Feignons!',1,2),(7,'Feignez!',0,2),(8,'Feins!',0,2),(9,'Calcutta',0,3),(10,'Mumbai',0,3),(11,'New Delhi',1,3),(12,'Bangalore',0,3),(13,'Le macadamia',0,4),(14,'Le noisetier',0,4),(15,'Le pacanier',1,4),(16,'Le pécunier',0,4),(17,'La Suède',1,5),(18,'La Finlande',0,5),(19,'La norvège',0,5),(20,'Le Danemark',0,5),(21,'Un triangle qui a un angle droit',0,6),(22,'Un triangle qui a deux côtés de même longueur',1,6),(23,'Un triangle qui a trois côtés de même longueur',0,6),(24,'Un triangle qui a trois angles égaux',0,6),(25,'Un triangle',0,7),(26,'Un pentagone',0,7),(27,'Un cercle',1,7),(28,'Un carré',0,7),(29,'90°',0,8),(30,'180°',1,8),(31,'360°',0,8),(32,'720°',0,8),(33,'Amas de cabanes',0,9),(34,'Fin des eaux profondes',0,9),(35,'Lieu de rencontre',0,9),(36,'Là où le fleuve se rétrécit',1,9),(37,'Atlantique',0,10),(38,'Pacifique',1,10),(39,'Arctique',0,10),(40,'Indien',0,10),(41,'Halifax',0,11),(42,'Montréal',0,11),(43,'Ottawa',1,11),(44,'Québec',0,11),(45,'0',0,12),(46,'1',0,12),(47,'2',0,12),(48,'3',1,12),(49,'L’aigle impérial',0,13),(50,'L’orignal',0,13),(51,'Le castor',1,13),(52,'L’ours polaire',0,13),(53,'Mercure',0,14),(54,'Mars',1,14),(55,'Jupiter',0,14),(56,'Terre',0,14),(57,'déduction',0,15),(58,'mesure',0,15),(59,'inférence',1,15),(60,'hypothèse',0,15),(61,'Glucides',0,16),(62,'Graisses',0,16),(63,'Protéines',1,16),(64,'Vitamines',0,16),(65,'C’est un rectangle',0,17),(66,'C’est un carré',1,17),(67,'C’est un triangle rectangle',0,17),(68,'C’est un cercle',0,17),(69,'Le Québec',0,18),(70,'Le Manitoba',0,18),(71,'L’ontario',0,18),(72,'Le nouveau-Brunswick',1,18),(73,'Les plaquettes sanguines',0,19),(74,'Les globules blancs',0,19),(75,'Les lymphocytes T',0,19),(76,'Les globules rouges',1,19),(77,'Lac Érié',0,20),(78,'Lac Supérieur',1,20),(79,'Lac Ontario',0,20),(80,'Lac Michigan',0,20),(81,'L’éléphant',0,21),(82,'Le grand cachalot',0,21),(83,'Le rorqual',0,21),(84,'La baleine bleue',1,21),(85,'New York',0,22),(86,'Détroit',1,22),(87,'Seattle',0,22),(88,'Chicago',0,22),(89,'Nigeria',1,23),(90,'Éthiopie',0,23),(91,'Égypte',0,23),(92,'République démocratique du Congo',0,23),(93,'Uranus',0,24),(94,'Mars',0,24),(95,'Pluton',0,24),(96,'Neptune',1,24),(97,'Dans l’océan Indien, à la pointe de l’Inde',1,25),(98,'Dans l’océan Indien, à la pointe sud de Madagascar',0,25),(99,'Dans l’océan Pacifique, au nord des Philippines',0,25),(100,'Dans l’océan Pacifique, au nord de la Nouvelle-Zélande',0,25),(101,'Un amour de Québec',0,26),(102,'La Belle Province',1,26),(103,'Une province à découvrir',0,26),(104,'Québec pour toujours',0,26),(105,'Le Saint-Laurent au Québec et en Ontario',0,27),(106,'Le Mackenzie dans les Territoires du Nord-Ouest',1,27),(107,'Le Columbia en Colombie-Britannique',0,27),(108,'Le Fraser en Colombie-Britannique',0,27),(109,'L’hippopotame',0,28),(110,'Le moustique',1,28),(111,'Le crocodile',0,28),(112,'Le serpent',0,28),(113,'Jupiter',0,29),(114,'Mars',0,29),(115,'Uranus',0,29),(116,'Saturne',1,29),(117,'Jean Chrétien',0,30),(118,'Brian Mulroney',0,30),(119,'Paul Martin',1,30),(120,'Stephen Harper',0,30),(121,'De 1948 à 1973',0,31),(122,'De 1962 à 1978',0,31),(123,'De 1960 à 1976',0,31),(124,'De 1955 à 1975',1,31),(125,'Ozone',1,32),(126,'Azote',0,32),(127,'Oxygène',0,32),(128,'Dioxyde de Carbone',0,32),(129,'Pétrole',0,33),(130,'Carbone',0,33),(131,'Oxygène',1,33),(132,'Azote',0,33),(133,'Le Brésil',0,34),(134,'L’Allemagne',1,34),(135,'L’Italie',0,34),(136,'L’Argentine',0,34),(137,'Une marâtre',1,35),(138,'Une jocrisse',0,35),(139,'Une godiche',0,35),(140,'Une chenapan',0,35),(141,'Si un triangle ABC est rectangle en C, alors : C² = A² + B²',0,36),(142,'Si un triangle ABC est rectangle en C, alors : AC² = AB² + BC²',0,36),(143,'Si un triangle ABC est rectangle en C, alors : AB² = AC² + BC²',1,36),(144,'Si un triangle ABC est rectangle en C, alors : C = A + B',0,36),(145,'5 et 39 ans',0,37),(146,'8 et 38 ans',1,37),(147,'9 et 37 ans',0,37),(148,'12 et 35 ans',0,37),(149,'New York',0,38),(150,'Washington',0,38),(151,'Genève',1,38),(152,'Zurich',0,38),(153,'La livre africaine',0,39),(154,'Le franc CFA',0,39),(155,'Le rand',1,39),(156,'Le riyal',0,39),(157,'Lumière suprême',0,40),(158,'Président suprême',0,40),(159,'Premier secrétaire du Parti communiste',0,40),(160,'Dirigeant suprême',1,40),(161,'C’est l’augmentation du pouvoir d’achat d’une monnaie par rapport à une autre qui se traduit par une baisse des prix',0,41),(162,'C’est l’augmentation des prix généralement associée à la baisse du chômage',0,41),(163,'C’est la perte du pouvoir d’achat d’une monnaie qui se traduit par une augmentation générale et durable des prix',1,41),(164,'C’est l’augmentation des prix en fonction d’une hausse de la demande d’un produit',0,41),(165,'Les alvéoles',0,42),(166,'Les poumons',0,42),(167,'Les bronches',1,42),(168,'Le diaphragme',0,42),(169,'1900',0,43),(170,'1910',0,43),(171,'1930',0,43),(172,'1940',1,43),(173,'Naruhito',0,44),(174,'Akihito',1,44),(175,'Hirohito',0,44),(176,'Taisho',0,44),(177,'De 1 à 2 litres',1,45),(178,'De 5 à 10 litres',0,45),(179,'De 15 à 20 litres',0,45),(180,'De 20 à 30 litres',0,45),(181,'Dans la jambe',1,46),(182,'Dans le bassin',0,46),(183,'Dans la main',0,46),(184,'Dans le bras',0,46),(185,'Nouvelle-Zélande',0,47),(186,'Turquie',0,47),(187,'Allemagne',0,47),(188,'Ouganda',1,47),(189,'Toutânkhamon',1,48),(190,'Ramsès II',0,48),(191,'Khéops',0,48),(192,'Cléopâtre',0,48),(193,'Saturne',0,49),(194,'Neptune',0,49),(195,'Mercure',1,49),(196,'Jupiter',0,49),(197,'Bill Gates',0,50),(198,'Warren Buffett',0,50),(199,'Carlos Slim Helú',0,50),(200,'Jeff Bezos',1,50),(201,'3 à 5 litres',0,51),(202,'4 à 6 litres',0,51),(203,'8 à 10 litres',1,51),(204,'12 à 15 litres',0,51),(205,'Watson et Crick',0,52),(206,'Louis Pasteurr',0,52),(207,'Robert Koch',0,52),(208,'Sir Alexander Fleming',1,52),(209,'Cratère',0,53),(210,'Lave',1,53),(211,'Geyser',0,53),(212,'Pierre de Feu',0,53);
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (1,'Quel célèbre dictateur dirigea l’URSS du milieu des années 1920 à 1953',1),(2,'Quel est l’impératif du verbe feindre à la première personne du pluriel',1),(3,'Quelle est la capitale de l’Inde',1),(4,'Quel arbre produit la noix de pécan',1),(5,'De quel pays, la ville Stockholm est-elle la capitale',1),(6,'Qu’est-ce qu’un triangle isocèle',1),(7,'Parmi ces figures, laquelle n’est pas un polygone',1),(8,'La somme des angles d’un triangle est égale à',1),(9,'Que veut dire le mot « kébec » en algonquin',1),(10,'Quel est le plus vaste océan du monde',1),(11,'Quelle est la capitale du Canada',1),(12,'Combien de fois le Canada a-t-il eu l’honneur d’accueillir les Jeux Olympiques',1),(13,'Quel animal est l’emblème officiel du Canada',1),(14,'Quelle planète est connue la planète rouge',1),(15,'Les trois méthodes de la science sont observation, expérimentation et _______',1),(16,'Les enzymes et les anticorps sont principalement constitué de',1),(17,'Si un losange a un angle droit, alors c’est un...',2),(18,'Quelle est la seule province canadienne possédant officiellement deux langues officielles',2),(19,'Quelles sont les cellules chargées de transporter l’oxygène dans l’organisme',2),(20,'Lequel de ces lacs est le plus grand d’Amérique du Nord',2),(21,'Quel est le plus gros animal sur Terre',2),(22,'À partir de quelle grande ville américaine un automobiliste peut-il se rendre au Canada en prenant la direction sud',2),(23,'Lequel de ces pays africains est le plus populeux',2),(24,'Quelle planète du système solaire est la plus éloignée du Soleil',2),(25,'Où est situé le Sri Lanka',2),(26,'La devise « Je me souviens » apparaît sur les plaques d’immatriculation des véhicules du Québec en 1978 et remplace celle-ci',2),(27,'Lequel de ces fleuves canadiens est le plus long',2),(28,'Lequel de ces animaux cause le plus de décès chez l’humain chaque année',2),(29,'Laquelle des planètes du système solaire possède le plus de lunes',2),(30,'Qui était premier ministre du Canada en 2004',2),(31,'La guerre du Vietnam s’est déroulée sur quelle période',2),(32,'Quel gaz dans l’atmosphère nous protège des rayonnements ultraviolets nocifs',2),(33,'Lequel des suivants est nécessaire à la combustion',2),(34,'Quel pays a remporté la coupe du monde de football en 2014',3),(35,'Par quel mot désigne-t-on une belle-mère cruelle',3),(36,'Quel est le théorème de Pythagore',3),(37,'Un garçon a 30 ans de moins que son père. Dans 7 ans, son âge sera le tiers de celui de son père. Quels sont les âges du fils et du père',3),(38,'Dans quelle ville siège l’Organisation mondiale du commerce, OMC',3),(39,'Quelle monnaie circule en Afrique du Sud',3),(40,'Quel est le titre officiel de Kim Jong-un, le dictateur à la tête de la Corée du Nord',3),(41,'Qu’est-ce que l’inflation',3),(42,'La trachée est un conduit constitué de tissu cartilagineux qui relie le larynx à quelle autre partie du corps humain',3),(43,'En quelle année les femmes ont-elles obtenu le droit de vote au Québec',3),(44,'Quel est le nom de l’empereur du Japon qui a abdiqué en avril dernier, cédant son trône à son fils après 30 ans de règne',3),(45,'La sécrétion quotidienne de salive d’un adulte est d’environ…',3),(46,'Où se trouve l’os péroné',3),(47,'Lequel de ces pays est le plus proche de l’équateur',3),(48,'Lequel de ces pharaons a connu le règne le plus court',3),(49,'Je ne suis pas considérée comme étant l’une des planètes gazeuses du système solaire',3),(50,'Je suis l’homme le plus riche au monde en 2018, selon le magazine Forbes',3),(51,'Combien y a-t-il, en moyenne, de litres de sang dans un corps humain adulte',3),(52,'Qui a découvert la Pénicilline',3),(53,'Quel est le nom donné à la fusion des roches qui entre en éruption d’un volcan',3);
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `questionquiz`
--

LOCK TABLES `questionquiz` WRITE;
/*!40000 ALTER TABLE `questionquiz` DISABLE KEYS */;
/*!40000 ALTER TABLE `questionquiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('Khalid_drag@gmail.com','Etudiant','Drag','Khalid','root'),('Marwenbouriel@gmail.com','Enseignant','Bouriel','Marwen','root'),('Massoud_baz@gmail.com','Enseignant','Baz','Massoud','root');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-31 22:47:55
