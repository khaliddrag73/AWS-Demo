﻿function verify(user) {
    if (user == "Etudiant")
    {
        document.getElementById("aq").style.visibility = "hidden";
        document.getElementById("sr").style.visibility = "hidden";
    }
    else
    {
        document.getElementById("aq").style.visibility = "visible";
        document.getElementById("sr").style.visibility = "visible";
    }
}