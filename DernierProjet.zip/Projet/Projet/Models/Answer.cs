﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace Projet.Models
{
    public partial class Answer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AnswerId { get; set; }
        public int? OptionId { get; set; }
        public int? QuizId { get; set; }

        public virtual Option Option { get; set; }
        public virtual Quiz Quiz { get; set; }
    }
}
