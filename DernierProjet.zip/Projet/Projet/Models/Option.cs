﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace Projet.Models
{
    public partial class Option
    {
        public Option()
        {
            Answers = new HashSet<Answer>();
        }
        [Key]
        public int OptionId { get; set; }
        public string Texte { get; set; }
        public bool IsRight { get; set; }
        public int? QuestionId { get; set; }

        public virtual Question Question { get; set; }
        public virtual ICollection<Answer> Answers { get; set; }
    }
}
