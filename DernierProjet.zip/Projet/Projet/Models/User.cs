﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace Projet.Models
{
    public partial class User
    {
        [Key]
        [Required]
        [EmailAddress(ErrorMessage ="Address Email is required!")]
        public string Email { get; set; }
        [Required]
        public string Statut { get; set; }
        [Required]
        public string Nom { get; set; }
        [Required]
        public string Prenom { get; set; }
        public string Password { get; set; }
    }
}
