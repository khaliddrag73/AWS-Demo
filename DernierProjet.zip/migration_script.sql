-- ----------------------------------------------------------------------------
-- MySQL Workbench Migration
-- Migrated Schemata: GestionQuizs
-- Source Schemata: GestionQuizs
-- Created: Mon May 31 22:34:49 2021
-- Workbench Version: 8.0.25
-- ----------------------------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- Schema GestionQuizs
-- ----------------------------------------------------------------------------
DROP SCHEMA IF EXISTS `GestionQuizs` ;
CREATE SCHEMA IF NOT EXISTS `GestionQuizs` ;

-- ----------------------------------------------------------------------------
-- Table GestionQuizs.Category
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `GestionQuizs`.`Category` (
  `CategoryID` INT NOT NULL,
  `Description` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`CategoryID`));

-- ----------------------------------------------------------------------------
-- Table GestionQuizs.Question
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `GestionQuizs`.`Question` (
  `QuestionID` INT NOT NULL,
  `Texte` VARCHAR(250) NOT NULL,
  `CategoryID` INT NULL,
  PRIMARY KEY (`QuestionID`),
  CONSTRAINT `FK__Question__Catego__267ABA7A`
    FOREIGN KEY (`CategoryID`)
    REFERENCES `GestionQuizs`.`Category` (`CategoryID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

-- ----------------------------------------------------------------------------
-- Table GestionQuizs.Options
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `GestionQuizs`.`Options` (
  `OptionID` INT NOT NULL,
  `Texte` VARCHAR(250) NOT NULL,
  `IsRight` TINYINT(1) NOT NULL,
  `QuestionID` INT NULL,
  PRIMARY KEY (`OptionID`),
  CONSTRAINT `FK__Options__Questio__29572725`
    FOREIGN KEY (`QuestionID`)
    REFERENCES `GestionQuizs`.`Question` (`QuestionID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

-- ----------------------------------------------------------------------------
-- Table GestionQuizs.Quiz
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `GestionQuizs`.`Quiz` (
  `QuizID` INT NOT NULL,
  `Nom` VARCHAR(50) NOT NULL,
  `Email` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`QuizID`));

-- ----------------------------------------------------------------------------
-- Table GestionQuizs.Answer
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `GestionQuizs`.`Answer` (
  `AnswerID` INT NOT NULL,
  `OptionID` INT NULL,
  `QuizID` INT NULL,
  PRIMARY KEY (`AnswerID`),
  CONSTRAINT `FK__Answer__OptionID__2E1BDC42`
    FOREIGN KEY (`OptionID`)
    REFERENCES `GestionQuizs`.`Options` (`OptionID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK__Answer__QuizID__2F10007B`
    FOREIGN KEY (`QuizID`)
    REFERENCES `GestionQuizs`.`Quiz` (`QuizID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

-- ----------------------------------------------------------------------------
-- Table GestionQuizs.QuestionQuiz
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `GestionQuizs`.`QuestionQuiz` (
  `QuestionID` INT NOT NULL,
  `QuizID` INT NOT NULL,
  PRIMARY KEY (`QuestionID`, `QuizID`),
  CONSTRAINT `FK__QuestionQ__Quest__31EC6D26`
    FOREIGN KEY (`QuestionID`)
    REFERENCES `GestionQuizs`.`Question` (`QuestionID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK__QuestionQ__QuizI__32E0915F`
    FOREIGN KEY (`QuizID`)
    REFERENCES `GestionQuizs`.`Quiz` (`QuizID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

-- ----------------------------------------------------------------------------
-- Table GestionQuizs.Users
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `GestionQuizs`.`Users` (
  `Email` VARCHAR(50) NOT NULL,
  `Statut` VARCHAR(20) NOT NULL,
  `Nom` VARCHAR(20) NOT NULL,
  `Prenom` VARCHAR(20) NOT NULL,
  `Password` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`Email`));
SET FOREIGN_KEY_CHECKS = 1;
